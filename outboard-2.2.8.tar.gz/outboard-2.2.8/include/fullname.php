<?php

// fullname.php
//
// If you have a method to get people's real/full names, put the
// code in this function. By default, it just returns the userid
// that it is sent.
// 
// 2005-02-17	Richard F. Feuerriegel	(richardf@aces.edu)
//

Function get_fullname($userid) {
  return $userid;
}

?>
