<?php

// about.php
//
// 2002-04-11, Richard F. Feuerriegel (richardf@acesag.auburn.edu)
// 	- Initial creation

?>

  <a href="http://www.aces.edu/~feuerri/outboard/" 
     target=_blank>OutBoard</a> <?php echo $version ?> &copy;<?php echo $version_date ?> 
     <a href="http://www.aces.edu/~feuerri" target=_blank>Richard F. Feuerriegel</a>

